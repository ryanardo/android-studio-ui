package com.epicodus.myrestaurants.util;

/**
 * Created by Guest on 4/2/18.
 */

public class SimpleItemTouchHelperCallback {
}
