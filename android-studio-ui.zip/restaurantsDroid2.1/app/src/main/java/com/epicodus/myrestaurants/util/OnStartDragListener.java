package com.epicodus.myrestaurants.util;

import android.support.v7.widget.RecyclerView;

/**
 * Created by Guest on 4/2/18.
 */

public interface OnStartDragListener {
    void onStartDrag(RecyclerView.ViewHolder viewHolder);
}

